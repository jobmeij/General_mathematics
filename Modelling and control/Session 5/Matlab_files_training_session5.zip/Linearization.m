%% initilize model parameters
clc; clear all; 
% close all

% run initialization file
Init

% Figure options:
opts = bodeoptions;
opts.FreqUnits = 'Hz';
opts.XLim = {[1 4000]};
opts.Grid = 'on';

% Specify the model name
model = 'XYZ_motion_platform'; 
% model = 'XYZ_motion_platform_start'; 

%% Linearize the model by using "linearize"
% linearization options
opt = linearizeOptions;
opt.UseExactDelayModel = 'on';

% Get the analysis I/Os from the model
io = getlinio(model);
% linearization
sys = linearize(model,io,opt);

figure(1)
bode(sys,opts);


%% plot bode
% make sure frequency array stops at 4000 Hz
freqs  = logspace(0,log10(4000),Fs/2);  

[H] = freqresp(sys,freqs,'Hz');

for jj = 1:length(freqs)
    Model_xx(1,jj) = H(1,1,jj);  
end

figure(2) 
h1 = subplot(211);    % Plant estimate for F_x to x
    semilogx(freqs, 20*log10(abs(Model_xx)),'LineWidth',2); hold on;
    ylabel('Magnitude [dB]','Interpreter','latex');
    title('Plant of the X-stage','Interpreter','latex');
    xlim([1 4000]);
    grid on; 
h2 = subplot(212);   
    semilogx(freqs, unwrap(radtodeg(angle(Model_xx))),'LineWidth',2); hold on;
    ylabel('Phase [deg.]','Interpreter','latex');
    xlabel('Frequency [Hz]','Interpreter','latex');
    xlim([1 4000]);
    grid on;



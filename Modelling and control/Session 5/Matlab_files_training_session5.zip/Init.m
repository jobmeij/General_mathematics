% -------------------------------------------------------------------------
% ASM PT Beuningen
% Procedure for initialization of the Simscape Multibody model of a 
% XYZ-motion stage wire bonder 
% -------------------------------------------------------------------------

% This file produces all the initial parameters of the XYZ-motion platform
% of a wire bonder system
%
% Code written by: Stijn Beer          18-11-2020
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all;  clc;
% close all;

Fs          = 8000;     % Sampling frequency
Ts          = 1/Fs;     % Sampling time
Tsim        = 0.2;      % Simulation time
samp_delay  = 2.5;      % number of samples delay in the system

xref       = 1;     % reference signal on X-stage: 1 = yes, 0 = no

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% load feedback controller 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
load('./Controllers/C_fb_x_120Hz.mat');
[C_fb_x.num,C_fb_x.den] = tfdata(shapeit_data.C_tf_z,'v');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% load setpoint profiles 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
load('./setpoint_profiles/4mm_20G_X_1900.mat');
time_x    =  X_setpoints.Ref1(:,1);
ref_x     =  X_setpoints.Ref1(:,2:end);

% creating signal structs
x_ref.time                  = [];
x_ref.signals.values        = ref_x;
x_ref.signals.dimensions    = 5;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% SISO Feedforward parameters 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% SISO Feedforward parameters from F_x to x
K_a_xx = 0.0631;          % acceleration FF in X-direction

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Non-adaptable parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% During this Mechatronics Training Session it is not required to adapt the
% parameters that are given in this section. 

% ------------------------------------------------------------------------- 
% initial XY-position
% ------------------------------------------------------------------------- 
conf.x0     = 0.00; %[m] initial position of the X-stage in the x-direction
conf.y0     = 0.00; %[m] initial position of the Y-stage in the y-direction

% ------------------------------------------------------------------------- 
% Mass of the base, X-, Y- and Z-stage [kg]
% ------------------------------------------------------------------------- 
mod.m_base      = 2000;   
mod.m_zstage    = 0.13701;
mod.m_ystage    = 2.3 - mod.m_zstage;
mod.m_xstage    = 3.8 - mod.m_ystage;

% ------------------------------------------------------------------------- 
% Planar joint constraints between the world (W) and the base frame (BF)
% -------------------------------------------------------------------------  
mod.k_WtoBF_x   = 2.7e7;            % [N/m] stiffness coefficient in x-direction
mod.d_WtoBF_x   = 16000;            % [N/(m/s)] damping coefficient in x-direction 

mod.k_WtoBF_y   = mod.k_WtoBF_x;   	% [N/m] stiffness coefficient in y-direction    
mod.d_WtoBF_y   = mod.d_WtoBF_x;    % [N/(m/s)] damping coefficient in y-direction

% -------------------------------------------------------------------------  
% Planar joint constraints between the base frame (BF) and the X-stage (X)
% ------------------------------------------------------------------------- 
mod.k_BFtoX_x   = 0;        % [N/m] stiffness coefficient in x-direction
mod.d_BFtoX_x   = 60;       % [N/(m/s)] damping coefficient in x-direction  

mod.k_BFtoX_y   = 1.2e7;   	% [N/m] stiffness coefficient in y-direction  
mod.d_BFtoX_y   = 200;     	% [N/(m/s)] damping coefficient in y-direction 

% -------------------------------------------------------------------------  
% Planar joint constraints between the X-stage (X) and the Y-stage (Y)
% -------------------------------------------------------------------------  
mod.k_XtoY_x   = 1.2e7;   	% [N/m] stiffness coefficient in x-direction 
mod.d_XtoY_x   = 200;      	% [N/(m/s)] damping coefficient in x-direction 

mod.k_XtoY_y   = 0;       	% [N/m] stiffness coefficient in y-direction  
mod.d_XtoY_y   = 20;      	% [N/(m/s)] damping coefficient in y-direction

% ------------------------------------------------------------------------- 
% Dimensions of the Base, X-, Y- and Z-stage [m]
% ------------------------------------------------------------------------- 
dim.L_base          = 0.17;     % Length of the base frame
dim.H_base          = 0.06;     % Height of the base frame without guides
dim.W_xguide        = 0.10;     % Width between the guides of the X-stage

dim.H_guides        = 0.01;     % Heigth of the guides %% HAS TO BE SMALLER THAN H2_xstage %%
dim.W_guides        = 0.01;     % Width of the guides

dim.L_xstage        = 0.17;     % Length of the X-stage
dim.W_xstage        = 0.17;     % Width of the X-stage
dim.H1_xstage       = 0.018;    % Height of the bottom part of the X-stage
dim.H2_xstage       = 0.02;     % Height of the top part of the X-stage

dim.L_ystage        = 0.17;     % Length of the Y-stage
dim.W_ystage        = 0.065;    % Width of the Y-stage
dim.H1_ystage       = 0.02;     % Height of the bottom part of the Y-stage
dim.H2_ystage       = 0.045;    % Height of the top part of the Y-stage
dim.Block_ystage    = 0.05;     % Width of the Block on top of the Y-stage
dim.gap_ystage      = 0.02;     % Gap between block and front of Y-stage

dim.L_zstage        = 0.08;     % Length of the Z-stage
dim.W_zstage        = 0.01;     % Width of the Z-stage
dim.H_zstage        = 0.01;     % Height of the Z-stage

dim.L_sensor        = 0.17;     % Length of the sensor
dim.W_sensor        = 0.03;     % Width of the sensor
dim.H_xsensor       = 0.015;    % Height of the sensor X-stage
dim.H_ysensor       = 0.02;     % Height of the sensor Y-stage

% ------------------------------------------------------------------------- 
% Locations of the joints, encoders and forces [m]
% ------------------------------------------------------------------------- 
loc.joint_BtoX  = 0.055;  % Distance from midpoint of guide to joint
loc.joint_XtoY  = 0.055;  % Distance from midpoint of guide to joint

% ------------------------------------------------------------------------- 
% Revolute joint constraint between the Y-stage (Y) and the Z-stage (Z)
% ------------------------------------------------------------------------- 
mod.k_YtoZ      = 0.036;           % [Nm/deg]  
mod.d_YtoZ      = 0.0002;          % [Nm/(deg/s)] 

% ------------------------------------------------------------------------- 
% Others
% ------------------------------------------------------------------------- 
mod.b32z    = -0.003;   % [m]   (3 mm) draaipunt Z-stage
Kx          = 62.9;     % [N/A] motor constant in x
Ky          = 26.2;     % [N/A] motor constant in y
Kz          = 1/15;     % [N/A] motor constant in z


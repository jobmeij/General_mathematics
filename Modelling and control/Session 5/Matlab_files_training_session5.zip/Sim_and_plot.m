% -------------------------------------------------------------------------
% ASM PT Beuningen
% Procedure for performing time domain simulations with the Simscape 
% Multibody model of a XYZ-motion stage wire bonder 
% -------------------------------------------------------------------------
%
% Code written by: Stijn Beer          18-11-2020
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all; clc; 
close all;

Init

addpath('FMU');


%% Simulate the specified model 
%sim('XYZ_motion_platform');
sim('XYZ_motion_platform_FMU');

% load simulation data:
t           = sd.Time;
F_x         = sd.Data(:,1);
x_actual    = sd.Data(:,2);
y_actual 	= sd.Data(:,3);
x_ref       = sd.Data(:,4);
e_x         = sd.Data(:,5);

%% figures

figure(1)
subplot(211)
    plot(t,x_ref,'Linewidth',2,'Linestyle','-'); grid on; hold on;
    xlabel('Time [s]','Interpreter','latex');
    ylabel('Position $x$ [m]','Interpreter','latex');
subplot(212)
    plot(t,e_x,'Linewidth',2,'Linestyle','-'); grid on; hold on;
    xlabel('Time [s]','Interpreter','latex');
    ylabel('Error $e_x$ [m]','Interpreter','latex');
%     legend('Only feedback','Feedback and feedforward');

% Here a feedback controller needs to be tuned using loopshaping for the 
% AB383 model y-axis. The acceleration feedforward gain also needs to be
% estimated.
%% Initialization
%%
% Start clean
clc; clear all; close all;

%%
% Sampling time and frequency
Fs = 8000;
Ts = 1/Fs;

%%
% Laplace variable
s = tf('s');

%%
% Bode plot settings
bopts = bodeoptions;
bopts.FreqUnits = 'Hz';
bopts.Grid = 'on';
bopts.XLim = [1, Fs/2];

%%
% create FRD object plant
load('.\plants\G_yy.mat')
f = 1:1:Fs/2; % frequency vector from 1 Hz to nyquist frequency
resp = freqresp(sys,f*2*pi); % frequency response vector
G = frd(resp,2*pi*f); % frd object construction

%%
% bode plot plant
figure
bode(G,bopts)
title('Plant: G')
set(findall(gcf,'type','line'),'linewidth',1.5)

%% controller tuning
% ...

%% Estimation of acceleration feedforward constant
% ...


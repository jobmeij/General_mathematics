% Here a feedback controller is tuned using loopshaping for the AB383 model
% x-axis. The acceleration feedforward gain is also estimated.
%% Initialization
%%
% Start clean
clc; clear all; close all;

%%
% Sampling time and frequency
Fs = 8000;
Ts = 1/Fs;

%%
% Laplace variable
s = tf('s');

%%
% Bode plot settings
bopts = bodeoptions;
bopts.FreqUnits = 'Hz';
bopts.Grid = 'on';
bopts.XLim = [1, Fs/2];

%%
% create FRD object plant
load('.\plants\G_xx.mat')
f = 1:1:Fs/2; % frequency vector from 1 Hz to nyquist frequency
resp = freqresp(sys,f*2*pi); % frequency response vector
G = frd(resp,2*pi*f); % frd object construction

%%
% bode plot plant
figure
bode(G,bopts)
title('Plant: G')
set(findall(gcf,'type','line'),'linewidth',1.5)

%% controller tuning
%%
% desired bandwidth (Hz)
f_bw = 120;

%%
% Tune controller gain: K
mag_G_at_f_bw = db2mag(-91.2); % magnitude plant at desired bandwidth
K = 0.33/mag_G_at_f_bw;

%%
% Tune lead/lag controller part: C_lead_lag
f_lead = 0.33*f_bw;
f_lag = 3*f_bw;
C_lead_lag = (1/(2*pi*f_lead)*s+1)/(1/(2*pi*f_lag)*s+1); % magnitude plant at desired bandwidth

%%
% Tune integrator controller part: C_i
f_i = 0.1*f_bw;
C_i = (s+2*pi*f_i)/s; % magnitude plant at desired bandwidth

%%
% Total controller
C = K*C_lead_lag*C_i;

%%
% discretize controller
G_d = G;
G_d.Ts = Ts;
C_d = c2d(C,Ts,'tustin');

%%
% bode plot controller
figure
bode(C,bopts)
hold on
bode(C_d,bopts)
legend('Continious controller','Discretized controller')
title('Controller: C')
set(findall(gcf,'type','line'),'linewidth',1.5)

%% Open loop
%%
% Calculation open loop
L = G*C;
L_d = G_d*C_d;

%%
% bode plot open loop
figure
bode(L,bopts)
hold on
bode(L_d,bopts)
title('Open Loop: L')
legend('Continious controller','Discretized controller')
set(findall(gcf,'type','line'),'linewidth',1.5)

%%
% nyquist plot
resp_L = squeeze(L.resp); % vector with complex frequency values L
resp_L_d = squeeze(L_d.resp);
figure
plot(real(resp_L),imag(resp_L),'linewidth',1.5)
hold on
plot(real(resp_L_d),imag(resp_L_d),'linewidth',1.5)
circle(-1,0,.5); % plot circle corresponding to modulus margin of 6 dB 
grid on
axis([-4.5 0.5 -3 2])
legend('Continious Open Loop: L','Discrete Open Loop: L','6dB modulus margin')
title('Nyquist plot')
ylabel('Imaginary axis')
xlabel('Real axis')

%% Sensitivity
%%
% Calculation sensitivity
S = 1/(1+L);
S_d = 1/(1+L_d);

%%
% bode plot sensitivity
figure
bopts.PhaseVisible='off'; % only show magnitude characteristics
bode(S,bopts)
hold on
bode(S_d,bopts)
legend('Continious controller','Discretized controller')
title('Sensitivity: S')
set(findall(gcf,'type','line'),'linewidth',1.5)

%% Complementary ensitivity
%%
% Calculation complementary sensitivity
T = L/(1+L);
T_d = L_d/(1+L_d);

%%
% bode plot complementary sensitivity
figure
bode(T,bopts)
hold on
bode(T_d,bopts)
legend('Continious controller','Discretized controller')
title('Complementary sensitivity: T')
set(findall(gcf,'type','line'),'linewidth',1.5)

%% Estimation of acceleration feedforward constant
%%
% calculate FRF from force to acceleration
G_a = s^2*G;

%%
% bode plot FRF from force to acceleration
figure
bopts.PhaseVisible='on'; % only show magnitude characteristics
bode(G_a,bopts)
title('Plant from current to acceleration: G*s^2')
set(findall(gcf,'type','line'),'linewidth',1.5)

%% 
% Obtain the magnitude of the plat horizontal of the FRF for the estimation of 
% the acceleration feedforward parameter.
mag_flat_part = db2mag(24); % magnitude horizontal part
m_hat = 1/mag_flat_part; % estimated mass of the system

%% circle function
function h = circle(x,y,r)
hold on
th = 0:pi/50:2*pi;
xunit = r * cos(th) + x;
yunit = r * sin(th) + y;
h = plot(xunit, yunit,'linewidth',1.5);
hold off
end

%% initilize model parameters
clc; clear all; 
close all;

% run initialization file
Init

% Figure options:
opts = bodeoptions;
opts.FreqUnits = 'Hz';
opts.XLim = {[1 4000]};
opts.Grid = 'on';

% Specify the model name
model = 'XYZ_motion_platform'; 

%% Linearize the model by using "linearize"
% Get the analysis I/Os from the model
io = getlinio(model);
% linearization
sys = linearize(model,io);

figure(1)
bode(sys,opts);





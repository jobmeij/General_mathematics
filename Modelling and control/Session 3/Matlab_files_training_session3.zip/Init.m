clear all;  clc;
% close all;

Fs          = 8000;     % Sampling frequency
Ts          = 1/Fs;     % Sampling time

% ------------------------------------------------------------------------- 
% Mass of the base frame, the X-, Y- and Z-stage [kg]
% ------------------------------------------------------------------------- 
m_base      = 2000;     % Mass of the base frame
m_x         = 1.5;      % Mass of the X-stage
m_yz        = 2.3;      % Mass of the YZ-stage

% ------------------------------------------------------------------------- 
% Dimensions of the base frame, the X-, Y- and Z-stage [m]
% ------------------------------------------------------------------------- 
L_base      = 0.17;     % Length of the base stage (x-direction)
W_base   	= 0.10;     % Width of the base stage  (y-direction)
H_base     	= 0.06;     % Height of the base stage (z-direction)

L_xstage    = 0.17;     % Length of the X-stage (x-direction)
W_xstage   	= 0.10;     % Width of the X-stage  (y-direction)
H_xstage  	= 0.02;     % Height of the X-stage (z-direction)

L_yzstage   = 0.06;     % Length of the YZ-stage (x-direction)
W_yzstage   = 0.10;     % Width of the YZ-stage  (y-direction)
H_yzstage  	= 0.04;     % Height of the YZ-stage (z-direction)

% ------------------------------------------------------------------------- 
% Joint constraints 
% -------------------------------------------------------------------------  
% Joints between the fixed world and the base stage
k_b         = 1.08e8;   % [N/m] Translational stiffness
d_b         = 6.4e4;    % [Ns/m] Translational damping 
Rk_b        = 1/4*k_b*(W_base^2 + L_base^2); % [Nm/rad] Rotational stiffness 
Rd_b        = 1/4*d_b*(W_base^2 + L_base^2); % [Nm/(rad/s)] Rotational damping

% Joints between the base stage and the X-stage
d_fric_x    = 240;      % [Ns/m] Friction between the base stage and the X-stage
k_x         = 4.8e7;    % [N/m] Translational stiffness
d_x         = 800;      % [Ns/m] Translational damping
Rk_x        = 1/4*k_x*L_xstage^2; % [Nm/rad] Rotational stiffness 
Rd_x        = 1/4*(d_fric_x*W_xstage^2 + d_x*L_xstage^2); % [Nm/(rad/s)] Rotational damping

% Joints between the X-stage and the YZ-stage
d_fric_y    = 80;       % [Ns/m] Friction between the X-stage and the YZ-stage
k_y         = 4.8e7;    % [N/m] Translational stiffness
d_y         = 800;      % [Ns/m] Translational damping

